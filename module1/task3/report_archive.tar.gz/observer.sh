#!/bin/bash

CONFIG="observer.conf"
LOG="observer.log"

if [ ! -f "$CONFIG" ]; then
    echo "$(date +%Y-%m-%d %H:%M:%S) Конфигурационный файл $CONFIG не найден" >> "$LOG"
    exit 1
fi

while IFS= read -r TASK_NAME; do
    [[ -z "$TASK_NAME" || "$TASK_NAME" =~ ^# ]] && continue

    if ! pgrep -f "$TASK_NAME" > /dev/null; then
        nohup "./$TASK_NAME" > /dev/null 2>&1 &
        echo "$(date +%Y-%m-%d %H:%M:%S) Перезапущен $TASK_NAME (PID $!)" >> "$LOG"
    fi
done < "$CONFIG"
