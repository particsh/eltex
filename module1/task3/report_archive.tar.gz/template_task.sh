#!/bin/bash


SCRIPT_NAME="$(basename "$0")"

if [ "$SCRIPT_NAME" = "template_task.sh" ]; then
    echo "я бригадир, сам не работаю"
    exit 1
fi

FIFO="/tmp/run/cuckoo.pid"

LOG="report_${SCRIPT_NAME}.log"

START_TIME=$(date +%Y-%m-%d %H:%M:%S)
echo "$START_TIME [$$] Скрипт запущен" >> "$LOG"

echo "${SCRIPT_NAME}[$$]: how much time do I have?" > "$FIFO"

read N < "$FIFO"

sleep "$N"

END_TIME=$(date +%Y-%m-%d %H:%M:%S)
echo "$END_TIME [$$] Скрипт завершился, работал $N секунд" >> "$LOG"
