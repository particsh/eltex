#!/bin/bash

FIFO="/tmp/run/cuckoo.pid"
LOG="cuckoo.log"

cleanup() {
    echo "$(date +%F %T) Shutdown!" >> "$LOG"
    exec 3>&- 2>/dev/null
    rm -f "$FIFO"
    exit 0
}
trap cleanup SIGINT SIGTERM

mkdir -p "$(dirname "$FIFO")"
rm -f "$FIFO"
mkfifo "$FIFO"

exec 3<> "$FIFO"

echo "$(date +%F %T) Startup!" >> "$LOG"

while true; do
    if read -u 3 line; then
        if [[ $line =~ ^(.*)\[([0-9]+)\]:\ how\ much\ time\ do\ I\ have\?$ ]]; then
            N=$(( RANDOM % 9 + 2 ))
            echo "$(date +%F %T) ${BASH_REMATCH[1]}[${BASH_REMATCH[2]}] $N" >> "$LOG"
            echo "$N" >&3
        fi
    else
        sleep 0.1
    fi
done
